// server.js
const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
require("dotenv").config();

const app = express();
app.use(express.json());
app.use(cors());

// Rutas
const equiposRoutes = require("./routes/equipos");
const partidosRoutes = require("./routes/partidos");
const testRoute = require("./routes/test");

app.use("/api/equipos", equiposRoutes);
app.use("/api/partidos", partidosRoutes);
app.use("/api/test", testRoute);

// Conexión MongoDB
const PORT = process.env.PORT || 5000;
console.log("Conectando a MongoDB Atlas...");
mongoose.connect(process.env.MONGO_URI)
  .then(() => {
    console.log("Conectado a MongoDB Atlas");
    app.listen(PORT, () => console.log(`Servidor corriendo en puerto ${PORT}`));
  })
  .catch(err => console.error("❌ Error al conectar a MongoDB Atlas:", err));
