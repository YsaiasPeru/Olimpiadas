const mongoose = require("mongoose");

const PartidoSchema = new mongoose.Schema({
  equipoLocal: String,
  equipoVisitante: String,
  deporte: String,
  fecha: Date,
  resultado: String,
  comentarios: [{ texto: String }]
});

module.exports = mongoose.model("Partido", PartidoSchema);
