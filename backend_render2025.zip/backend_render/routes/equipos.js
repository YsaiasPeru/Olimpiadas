const express = require("express");
const router = express.Router();
const Equipo = require("../models/Equipo");

router.get("/", async (req, res) => {
  const equipos = await Equipo.find();
  res.json(equipos);
});

router.post("/", async (req, res) => {
  const nuevo = new Equipo(req.body);
  await nuevo.save();
  res.json(nuevo);
});

module.exports = router;
