const express = require("express");
const router = express.Router();
const Partido = require("../models/Partido");

router.get("/", async (req, res) => {
  const partidos = await Partido.find();
  res.json(partidos);
});

router.post("/", async (req, res) => {
  const nuevo = new Partido(req.body);
  await nuevo.save();
  res.json(nuevo);
});

module.exports = router;
