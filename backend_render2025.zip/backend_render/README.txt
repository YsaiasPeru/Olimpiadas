# Backend Olimpiadas (Listo para Render)
1. Sube esta carpeta a un repositorio en GitHub.
2. Conecta el repo a Render (crear servicio Web).
3. Configura en Render una variable de entorno: `MONGO_URI` con tu conexión real de Atlas.
4. Render usará automáticamente `npm install` y `npm start`.

Prueba: visita `https://TU-APP.onrender.com/api/test` para verificar que funciona.
